class IPTVAdmin {
    constructor() {
        this.isLoggedIn = false;
        this.channels = [];
        this.advertisement = '';
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        // Wait for Firebase to be available
        if (window.firebase) {
            this.loadData();
        } else {
            // Retry after a short delay
            setTimeout(() => {
                if (window.firebase) {
                    this.loadData();
                }
            }, 100);
        }
    }

    setupEventListeners() {
        // Login form
        document.getElementById('loginForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });

        // Logout button
        document.getElementById('logoutBtn').addEventListener('click', () => {
            this.handleLogout();
        });

        // Channel form
        document.getElementById('channelForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleAddChannel();
        });

        // Advertisement form
        document.getElementById('adForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleSaveAdvertisement();
        });

        // Ad content preview
        document.getElementById('adContent').addEventListener('input', (e) => {
            this.updateAdPreview();
        });

        // Reset view counts button
        document.getElementById('resetViewCountsBtn').addEventListener('click', () => {
            this.handleResetViewCounts();
        });
    }

    handleLogin() {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('loginError');

        // Clear previous errors
        errorDiv.classList.add('d-none');

        // Check credentials
        if (username === 'brahime@gmail.com' && password === 'Bra2025') {
            this.isLoggedIn = true;
            this.showAdminPanel();
            this.loadAdminData();
        } else {
            errorDiv.textContent = 'Invalid username or password';
            errorDiv.classList.remove('d-none');
        }
    }

    handleLogout() {
        this.isLoggedIn = false;
        this.showLoginForm();
        
        // Clear form data
        document.getElementById('loginForm').reset();
        document.getElementById('channelForm').reset();
        document.getElementById('adForm').reset();
    }

    showLoginForm() {
        document.getElementById('loginSection').style.display = 'flex';
        document.getElementById('adminPanel').style.display = 'none';
    }

    showAdminPanel() {
        document.getElementById('loginSection').style.display = 'none';
        document.getElementById('adminPanel').style.display = 'block';
    }

    async loadData() {
        try {
            // Load channels from Firestore
            const channelsCollection = window.firebase.collection(window.firebase.db, 'channels');
            const snapshot = await window.firebase.getDocs(channelsCollection);
            
            this.channels = [];
            snapshot.forEach((doc) => {
                const data = doc.data();
                this.channels.push({
                    id: doc.id,
                    name: data.name,
                    url: data.url,
                    logo: data.logo || '',
                    viewCount: data.viewCount || 0
                });
            });

            // Load advertisement from Firestore
            const adDoc = window.firebase.doc(window.firebase.db, 'settings', 'advertisement');
            const docSnapshot = await window.firebase.getDoc(adDoc);
            
            if (docSnapshot.exists()) {
                const data = docSnapshot.data();
                this.advertisement = data.content || '';
            } else {
                this.advertisement = '';
            }
            
        } catch (error) {
            console.error('Error loading data from Firebase:', error);
            this.channels = [];
            this.advertisement = '';
        }
    }

    async loadAdminData() {
        await this.loadData();
        this.renderExistingChannels();
        this.loadAdvertisementContent();
        this.renderViewCountDashboard();
        this.setupRealtimeListeners();
    }

    setupRealtimeListeners() {
        // Set up real-time listener for channels
        const channelsCollection = window.firebase.collection(window.firebase.db, 'channels');
        window.firebase.onSnapshot(channelsCollection, (snapshot) => {
            this.channels = [];
            snapshot.forEach((doc) => {
                const data = doc.data();
                this.channels.push({
                    id: doc.id,
                    name: data.name,
                    url: data.url,
                    logo: data.logo || '',
                    viewCount: data.viewCount || 0
                });
            });
            this.renderExistingChannels();
            this.renderViewCountDashboard();
        });
    }

    async handleAddChannel() {
        const name = document.getElementById('channelName').value.trim();
        const url = document.getElementById('channelUrl').value.trim();
        const logo = document.getElementById('channelLogo').value.trim();

        if (!name || !url) {
            alert('Please fill in channel name and URL');
            return;
        }

        // Validate URL format
        if (!url.includes('.m3u8')) {
            if (!confirm('The URL does not appear to be an M3U8 stream. Continue anyway?')) {
                return;
            }
        }

        try {
            // Create new channel document in Firestore
            const channelId = 'channel_' + Date.now();
            const channelDoc = window.firebase.doc(window.firebase.db, 'channels', channelId);
            
            await window.firebase.setDoc(channelDoc, {
                name: name,
                url: url,
                logo: logo || '',
                viewCount: 0,
                createdAt: new Date()
            });

            // Clear form
            document.getElementById('channelForm').reset();

            // Show success message
            this.showSuccessToast('Channel added successfully!');
            
        } catch (error) {
            console.error('Error adding channel:', error);
            alert('Error adding channel. Please try again.');
        }
    }

    async handleDeleteChannel(channelId) {
        if (confirm('Are you sure you want to delete this channel?')) {
            try {
                const channelDoc = window.firebase.doc(window.firebase.db, 'channels', channelId);
                await window.firebase.deleteDoc(channelDoc);
                this.showSuccessToast('Channel deleted successfully!');
            } catch (error) {
                console.error('Error deleting channel:', error);
                alert('Error deleting channel. Please try again.');
            }
        }
    }

    async handleSaveAdvertisement() {
        const adContent = document.getElementById('adContent').value.trim();
        
        try {
            const adDoc = window.firebase.doc(window.firebase.db, 'settings', 'advertisement');
            await window.firebase.setDoc(adDoc, {
                content: adContent,
                updatedAt: new Date()
            });
            
            this.advertisement = adContent;
            this.updateAdPreview();
            this.showSuccessToast('Advertisement saved successfully!');
            
        } catch (error) {
            console.error('Error saving advertisement:', error);
            alert('Error saving advertisement. Please try again.');
        }
    }

    // No longer needed - Firebase handles persistence automatically

    renderExistingChannels() {
        const container = document.getElementById('existingChannels');
        
        if (this.channels.length === 0) {
            container.innerHTML = `
                <div class="list-group-item text-center p-4">
                    <i class="fas fa-tv fa-2x text-muted mb-2"></i>
                    <p class="text-muted mb-0">No channels added yet</p>
                </div>
            `;
            return;
        }

        container.innerHTML = this.channels.map(channel => `
            <div class="list-group-item admin-channel-item">
                <div class="d-flex align-items-center">
                    ${channel.logo ? 
                        `<img src="${channel.logo}" alt="${channel.name}" class="channel-logo me-3" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                         <div class="channel-logo-placeholder me-3" style="display: none;">
                            <i class="fas fa-tv"></i>
                         </div>` :
                        `<div class="channel-logo-placeholder me-3">
                            <i class="fas fa-tv"></i>
                         </div>`
                    }
                    <div class="flex-grow-1">
                        <h6 class="mb-1">${this.escapeHtml(channel.name)}</h6>
                        <small class="text-muted">${this.escapeHtml(channel.url)}</small>
                    </div>
                    <button class="btn btn-danger btn-sm delete-btn" onclick="admin.handleDeleteChannel(${channel.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }

    loadAdvertisementContent() {
        const adTextarea = document.getElementById('adContent');
        adTextarea.value = this.advertisement;
        this.updateAdPreview();
    }

    updateAdPreview() {
        const adContent = document.getElementById('adContent').value.trim();
        const preview = document.getElementById('adPreview');
        
        if (adContent) {
            preview.innerHTML = adContent;
        } else {
            preview.innerHTML = '<p class="text-muted mb-0">No advertisement content set</p>';
        }
    }

    showSuccessToast(message) {
        const toast = document.getElementById('successToast');
        const toastMessage = document.getElementById('toastMessage');
        
        toastMessage.textContent = message;
        
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
    }

    renderViewCountDashboard() {
        const container = document.getElementById('viewCountDashboard');
        
        // Get view counts from localStorage
        let viewCounts = {};
        const storedCounts = localStorage.getItem('iptvViewCounts');
        if (storedCounts) {
            try {
                viewCounts = JSON.parse(storedCounts);
            } catch (e) {
                console.error('Error parsing view counts:', e);
            }
        }

        if (this.channels.length === 0) {
            container.innerHTML = `
                <div class="text-center p-4">
                    <i class="fas fa-chart-bar fa-2x text-muted mb-2"></i>
                    <p class="text-muted mb-0">No channels available to track</p>
                </div>
            `;
            return;
        }

        // Sort channels by view count (descending)
        const channelsWithCounts = this.channels.map(channel => ({
            ...channel,
            viewCount: viewCounts[channel.id] || 0
        })).sort((a, b) => b.viewCount - a.viewCount);

        const totalViews = channelsWithCounts.reduce((sum, channel) => sum + channel.viewCount, 0);

        container.innerHTML = `
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="card bg-primary text-white">
                        <div class="card-body text-center">
                            <h3 class="mb-0">${totalViews}</h3>
                            <small>Total Views</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card bg-info text-white">
                        <div class="card-body text-center">
                            <h3 class="mb-0">${this.channels.length}</h3>
                            <small>Total Channels</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Channel</th>
                            <th>Views</th>
                            <th>Popularity</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${channelsWithCounts.map((channel, index) => {
                            const percentage = totalViews > 0 ? Math.round((channel.viewCount / totalViews) * 100) : 0;
                            return `
                                <tr>
                                    <td>
                                        <span class="badge bg-${index === 0 ? 'warning' : index === 1 ? 'secondary' : index === 2 ? 'dark' : 'light'} text-dark">
                                            #${index + 1}
                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            ${channel.logo ? 
                                                `<img src="${channel.logo}" alt="${channel.name}" class="channel-logo me-2" style="width: 30px; height: 30px;" onerror="this.style.display='none';">` :
                                                `<div class="channel-logo-placeholder me-2" style="width: 30px; height: 30px; font-size: 12px;">
                                                    <i class="fas fa-tv"></i>
                                                </div>`
                                            }
                                            <span>${this.escapeHtml(channel.name)}</span>
                                        </div>
                                    </td>
                                    <td>
                                        <strong>${channel.viewCount}</strong>
                                    </td>
                                    <td>
                                        <div class="progress" style="height: 20px;">
                                            <div class="progress-bar" style="width: ${percentage}%">
                                                ${percentage}%
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            `;
                        }).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }

    async handleResetViewCounts() {
        if (confirm('Are you sure you want to reset all view counts? This action cannot be undone.')) {
            try {
                // Reset view counts for all channels
                const channelsCollection = window.firebase.collection(window.firebase.db, 'channels');
                const snapshot = await window.firebase.getDocs(channelsCollection);
                
                const promises = [];
                snapshot.forEach((doc) => {
                    const channelDoc = window.firebase.doc(window.firebase.db, 'channels', doc.id);
                    promises.push(window.firebase.updateDoc(channelDoc, {
                        viewCount: 0
                    }));
                });
                
                await Promise.all(promises);
                this.showSuccessToast('View counts reset successfully!');
                
            } catch (error) {
                console.error('Error resetting view counts:', error);
                alert('Error resetting view counts. Please try again.');
            }
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the admin panel when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.admin = new IPTVAdmin();
});
