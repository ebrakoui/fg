class IPTVPlayer {
    constructor() {
        this.channels = [];
        this.currentChannel = null;
        this.hls = null;
        this.videoPlayer = document.getElementById('videoPlayer');
        this.loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
        
        this.init();
    }

    init() {
        // Wait for Firebase to be available
        if (window.firebase) {
            this.loadChannels();
            this.loadAdvertisement();
            this.setupEventListeners();
        } else {
            // Retry after a short delay
            setTimeout(() => this.init(), 100);
        }
    }

    async loadChannels() {
        try {
            const channelsCollection = window.firebase.collection(window.firebase.db, 'channels');
            const snapshot = await window.firebase.getDocs(channelsCollection);
            
            this.channels = [];
            snapshot.forEach((doc) => {
                const data = doc.data();
                this.channels.push({
                    id: doc.id,
                    name: data.name,
                    url: data.url,
                    logo: data.logo || '',
                    viewCount: data.viewCount || 0
                });
            });
            
            this.renderChannelList();
            
            // Set up real-time listener for channel updates
            window.firebase.onSnapshot(channelsCollection, (snapshot) => {
                this.channels = [];
                snapshot.forEach((doc) => {
                    const data = doc.data();
                    this.channels.push({
                        id: doc.id,
                        name: data.name,
                        url: data.url,
                        logo: data.logo || '',
                        viewCount: data.viewCount || 0
                    });
                });
                this.renderChannelList();
            });
            
        } catch (error) {
            console.error('Error loading channels:', error);
            this.channels = [];
            this.renderChannelList();
        }
    }

    async loadAdvertisement() {
        try {
            const adDoc = window.firebase.doc(window.firebase.db, 'settings', 'advertisement');
            const docSnapshot = await window.firebase.getDoc(adDoc);
            
            const adContainer = document.getElementById('advertisementContent');
            
            if (docSnapshot.exists()) {
                const data = docSnapshot.data();
                if (data.content && data.content.trim() !== '') {
                    adContainer.innerHTML = data.content;
                } else {
                    adContainer.innerHTML = '<p class="text-muted mb-0">No advertisements available</p>';
                }
            } else {
                adContainer.innerHTML = '<p class="text-muted mb-0">No advertisements available</p>';
            }
            
            // Set up real-time listener for advertisement updates
            window.firebase.onSnapshot(adDoc, (doc) => {
                if (doc.exists()) {
                    const data = doc.data();
                    if (data.content && data.content.trim() !== '') {
                        adContainer.innerHTML = data.content;
                    } else {
                        adContainer.innerHTML = '<p class="text-muted mb-0">No advertisements available</p>';
                    }
                } else {
                    adContainer.innerHTML = '<p class="text-muted mb-0">No advertisements available</p>';
                }
            });
            
        } catch (error) {
            console.error('Error loading advertisement:', error);
            const adContainer = document.getElementById('advertisementContent');
            adContainer.innerHTML = '<p class="text-muted mb-0">No advertisements available</p>';
        }
    }

    renderChannelList() {
        const channelList = document.getElementById('channelList');
        
        if (this.channels.length === 0) {
            channelList.innerHTML = `
                <div class="list-group-item text-center p-4">
                    <i class="fas fa-tv fa-2x text-muted mb-2"></i>
                    <p class="text-muted mb-0">No channels available</p>
                    <small class="text-muted">Contact admin to add channels</small>
                </div>
            `;
            return;
        }

        channelList.innerHTML = this.channels.map((channel, index) => `
            <div class="list-group-item list-group-item-action channel-item" data-channel-index="${index}">
                <div class="d-flex align-items-center">
                    ${channel.logo ? 
                        `<img src="${channel.logo}" alt="${channel.name}" class="channel-logo me-3" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                         <div class="channel-logo-placeholder me-3" style="display: none;">
                            <i class="fas fa-tv"></i>
                         </div>` :
                        `<div class="channel-logo-placeholder me-3">
                            <i class="fas fa-tv"></i>
                         </div>`
                    }
                    <div class="flex-grow-1">
                        <h6 class="mb-1">${this.escapeHtml(channel.name)}</h6>
                        <small class="text-muted">Click to watch</small>
                    </div>
                    <i class="fas fa-play text-muted"></i>
                </div>
            </div>
        `).join('');
    }

    setupEventListeners() {
        // Channel selection
        document.getElementById('channelList').addEventListener('click', (e) => {
            const channelItem = e.target.closest('.channel-item');
            if (channelItem) {
                const channelIndex = parseInt(channelItem.dataset.channelIndex);
                this.selectChannel(channelIndex);
            }
        });

        // Video player error handling
        this.videoPlayer.addEventListener('error', (e) => {
            console.error('Video player error:', e);
            this.showError('Error loading video stream');
        });

        // Video player events
        this.videoPlayer.addEventListener('loadstart', () => {
            this.updateChannelStatus('Loading...');
        });

        this.videoPlayer.addEventListener('canplay', () => {
            this.updateChannelStatus('Ready to play');
        });

        this.videoPlayer.addEventListener('playing', () => {
            this.updateChannelStatus('Playing');
        });

        this.videoPlayer.addEventListener('pause', () => {
            this.updateChannelStatus('Paused');
        });

        this.videoPlayer.addEventListener('waiting', () => {
            this.updateChannelStatus('Buffering...');
        });
    }

    selectChannel(channelIndex) {
        if (channelIndex < 0 || channelIndex >= this.channels.length) {
            return;
        }

        const channel = this.channels[channelIndex];
        this.currentChannel = channel;

        // Update view count
        this.updateViewCount(channel.id);

        // Update UI
        this.updateActiveChannel(channelIndex);
        this.showCurrentChannelInfo(channel);
        this.loadStream(channel.url);
    }

    updateActiveChannel(activeIndex) {
        const channelItems = document.querySelectorAll('.channel-item');
        channelItems.forEach((item, index) => {
            if (index === activeIndex) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });
    }

    showCurrentChannelInfo(channel) {
        const channelInfo = document.getElementById('currentChannelInfo');
        const channelName = document.getElementById('currentChannelName');
        const noChannelMessage = document.getElementById('noChannelMessage');

        channelName.textContent = channel.name;
        channelInfo.style.display = 'block';
        noChannelMessage.style.display = 'none';
    }

    updateChannelStatus(status) {
        const statusElement = document.getElementById('currentChannelStatus');
        if (statusElement) {
            statusElement.textContent = status;
        }
    }

    loadStream(streamUrl) {
        this.loadingModal.show();

        // Clean up existing HLS instance
        if (this.hls) {
            this.hls.destroy();
            this.hls = null;
        }

        // Show video player
        this.videoPlayer.style.display = 'block';

        if (Hls.isSupported()) {
            this.hls = new Hls({
                enableWorker: true,
                lowLatencyMode: true,
                backBufferLength: 90,
                maxBufferLength: 30,
                maxMaxBufferLength: 600,
                maxBufferSize: 60 * 1000 * 1000,
                maxBufferHole: 0.5,
                manifestLoadingTimeOut: 10000,
                manifestLoadingMaxRetry: 4,
                manifestLoadingRetryDelay: 1000,
                levelLoadingTimeOut: 10000,
                levelLoadingMaxRetry: 4,
                levelLoadingRetryDelay: 1000,
                fragLoadingTimeOut: 20000,
                fragLoadingMaxRetry: 6,
                fragLoadingRetryDelay: 1000,
                startLevel: -1,
                autoStartLoad: true,
                debug: false
            });

            this.hls.loadSource(streamUrl);
            this.hls.attachMedia(this.videoPlayer);

            this.hls.on(Hls.Events.MANIFEST_PARSED, () => {
                this.loadingModal.hide();
                this.videoPlayer.play().catch(e => {
                    console.error('Error playing video:', e);
                    this.showError('Error playing video. Please try again.');
                });
            });

            this.hls.on(Hls.Events.ERROR, (event, data) => {
                console.error('HLS error:', data);
                
                if (data.fatal) {
                    this.loadingModal.hide();
                    switch (data.type) {
                        case Hls.ErrorTypes.NETWORK_ERROR:
                            this.showError('Network error. Please check your connection.');
                            break;
                        case Hls.ErrorTypes.MEDIA_ERROR:
                            this.showError('Media error. Stream may be unavailable.');
                            // Try to recover from media error
                            try {
                                this.hls.recoverMediaError();
                            } catch (e) {
                                console.error('Failed to recover from media error:', e);
                            }
                            break;
                        default:
                            this.showError('Stream error. Please try another channel.');
                            break;
                    }
                } else {
                    // Handle non-fatal errors (like buffer stalled)
                    if (data.details === 'bufferStalledError') {
                        console.warn('Buffer stalled, attempting to recover...');
                        // Don't show error to user for buffer stall, it's usually temporary
                        this.updateChannelStatus('Buffering...');
                    }
                }
            });
        } else if (this.videoPlayer.canPlayType('application/vnd.apple.mpegurl')) {
            // Safari native HLS support
            this.videoPlayer.src = streamUrl;
            this.videoPlayer.addEventListener('loadedmetadata', () => {
                this.loadingModal.hide();
                this.videoPlayer.play().catch(e => {
                    console.error('Error playing video:', e);
                    this.showError('Error playing video. Please try again.');
                });
            });
        } else {
            this.loadingModal.hide();
            this.showError('Your browser does not support HLS streaming.');
        }
    }

    showError(message) {
        this.updateChannelStatus('Error');
        
        // Create and show error alert
        const alertDiv = document.createElement('div');
        alertDiv.className = 'alert alert-danger alert-dismissible fade show mt-3';
        alertDiv.innerHTML = `
            <i class="fas fa-exclamation-triangle me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        const videoContainer = document.getElementById('videoContainer');
        videoContainer.appendChild(alertDiv);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }

    async updateViewCount(channelId) {
        try {
            const channelDoc = window.firebase.doc(window.firebase.db, 'channels', channelId);
            await window.firebase.updateDoc(channelDoc, {
                viewCount: window.firebase.increment(1)
            });
        } catch (error) {
            console.error('Error updating view count:', error);
        }
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the IPTV player when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new IPTVPlayer();
});
