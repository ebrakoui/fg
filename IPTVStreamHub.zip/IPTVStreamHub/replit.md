# IPTV Web System

## Overview

This is a complete IPTV web player system built with Flask that provides a dual-interface solution for streaming live TV channels. The system consists of a user-facing page for watching channels and an admin panel for content management. All data is stored locally in the browser using localStorage, making it a lightweight solution without requiring a database backend.

## System Architecture

### Frontend Architecture
- **Single Page Applications**: Two main interfaces (user and admin) built with vanilla JavaScript
- **Responsive Design**: Bootstrap 5 with dark theme for consistent UI across devices
- **Component-Based JavaScript**: Object-oriented approach with IPTVPlayer and IPTVAdmin classes
- **Real-time Data Sync**: Firebase Firestore integration for persistent and synchronized data

### Backend Architecture
- **Flask Web Framework**: Minimal Python backend serving static files and templates
- **Template Engine**: Jinja2 for HTML template rendering
- **Static File Serving**: Direct file serving for CSS, JavaScript, and assets
- **Development Server**: Built-in Flask development server with debug mode
- **Firebase Firestore**: Cloud NoSQL database for persistent data storage and real-time synchronization

### Video Streaming
- **HLS Support**: Integration with hls.js library for .m3u8 stream playback
- **Adaptive Streaming**: Automatic quality adjustment based on network conditions
- **Cross-Platform Compatibility**: Works on desktop and mobile browsers

## Key Components

### User Interface (`index.html`)
- **Video Player**: HLS-capable video player with loading states
- **Channel List**: Dynamic sidebar with channel logos and names
- **Advertisement Display**: Configurable ad content section
- **Responsive Layout**: Mobile-first design with Bootstrap grid system

### Admin Interface (`admin.html`)
- **Authentication System**: Simple login with hardcoded credentials
- **Channel Management**: Add, edit, and delete IPTV channels
- **Advertisement Management**: Rich text editor for ad content
- **Real-time Preview**: Live preview of advertisement content
- **View Count Dashboard**: Real-time analytics showing channel popularity with ranking system and reset functionality

### JavaScript Controllers
- **IPTVPlayer Class**: Handles channel loading, video playback, and UI interactions
- **IPTVAdmin Class**: Manages authentication, channel CRUD operations, and ad management

## Data Flow

### User Experience Flow
1. User visits index page
2. JavaScript loads channels from localStorage
3. User selects a channel from the sidebar
4. Video player loads and streams the selected channel
5. Advertisement content displays alongside the player

### Admin Management Flow
1. Admin accesses admin panel via direct URL
2. Authentication prompt with username/password validation
3. Admin can add new channels with name, URL, and logo
4. Admin can modify advertisement content with live preview
5. All changes are saved to localStorage immediately

## External Dependencies

### Frontend Libraries
- **Bootstrap 5**: UI framework with dark theme
- **Font Awesome 6**: Icon library for UI elements
- **hls.js**: JavaScript library for HLS video streaming

### Backend Dependencies
- **Flask**: Python web framework
- **Jinja2**: Template engine (included with Flask)

### Development Dependencies
- **Python 3.x**: Runtime environment
- **Standard Library**: No additional Python packages required

## Deployment Strategy

### Local Development
- Flask development server on port 5000
- Debug mode enabled for development
- Static file serving through Flask

### Production Considerations
- Static files should be served by a web server (nginx/Apache)
- Flask should run behind a WSGI server (gunicorn/uWSGI)
- HTTPS recommended for streaming content
- Consider CDN for static assets

### Environment Configuration
- Session secret key configurable via environment variable
- Host and port settings for different deployment environments

## Authentication & Security

### Admin Access
- **Credentials**: Username: brahime@gmail.com, Password: Bra2025
- **URL Protection**: Admin panel only accessible via direct URL knowledge
- **Client-Side Authentication**: JavaScript-based login validation
- **Session Management**: Simple flag-based session handling

### Security Considerations
- Authentication is client-side only (not production-ready)
- No CSRF protection implemented
- Hardcoded credentials should be externalized
- Consider implementing server-side session management

## Data Management

### Firebase Firestore Collections

#### Channels Collection (`channels`)
```json
{
  "id": "channel_timestamp",
  "name": "Channel Name",
  "url": "https://stream.m3u8",
  "logo": "https://logo.url",
  "viewCount": 0,
  "createdAt": "2025-07-04T21:30:00Z"
}
```

#### Settings Collection (`settings`)
```json
{
  "advertisement": {
    "content": "HTML or plain text content",
    "updatedAt": "2025-07-04T21:30:00Z"
  }
}
```

### Real-time Features
- Live channel updates across all connected clients
- Real-time view count synchronization
- Instant advertisement content updates
- Automatic data persistence without manual saves

### Firebase Configuration
- Project ID: etva-2e627
- Authentication Domain: etva-2e627.firebaseapp.com
- Real-time listeners for live data updates
- Incremental view count tracking

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 04, 2025. Initial setup
- July 04, 2025. Enhanced admin panel with view count dashboard featuring real-time analytics, channel rankings, and improved HLS error handling for better streaming stability
- July 04, 2025. Integrated Firebase Firestore for persistent data storage, real-time synchronization across clients, and scalable cloud database infrastructure