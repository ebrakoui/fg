import os
from flask import Flask, render_template, send_from_directory

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "fallback-secret-key")

@app.route('/')
def index():
    """User-facing page to watch channels"""
    return render_template('index.html')

@app.route('/admin')
def admin():
    """Admin panel for managing channels and ads"""
    return render_template('admin.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    """Serve static files"""
    return send_from_directory('static', filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
